import os
import pandas as pd

def remove_column_from_csv(input_folder_path, output_folder_path, column_name):
    # Make sure the output folder exists
    if not os.path.exists(output_folder_path):
        os.makedirs(output_folder_path)
    
    # Iterate over all files in the specified input folder
    for filename in os.listdir(input_folder_path):
        # Check if the file is a CSV file
        if filename.endswith('.csv'):
            input_file_path = os.path.join(input_folder_path, filename)
            output_file_path = os.path.join(output_folder_path, filename)
            
            # Read the CSV file into a DataFrame
            df = pd.read_csv(input_file_path)
            
            # Check if the column exists in the DataFrame
            if column_name in df.columns:
                # Remove the specified column
                df.drop(columns=[column_name], inplace=True)
                print(f'Removed column "{column_name}" from {filename}')
            
            # Save the modified DataFrame to the new folder
            df.to_csv(output_file_path, index=False)

# Specify the input folder path, output folder path, and the column name to be removed
input_folder_path = 'C:/Users/DELL/Desktop/sliot/Dialog Data Collection/LatestData/combinedWatts'
output_folder_path = 'C:/Users/DELL/Desktop/sliot/Dialog Data Collection/LatestData/combinedWattswithoutWM'
column_name = 'washing_machine'

# Call the function to remove the column from all CSV files in the input folder and save to the output folder
remove_column_from_csv(input_folder_path, output_folder_path, column_name)
